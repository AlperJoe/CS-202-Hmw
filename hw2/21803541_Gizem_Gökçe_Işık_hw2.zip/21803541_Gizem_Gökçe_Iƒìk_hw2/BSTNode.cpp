/**
* Title: Binary Search Trees
* Author : Gizem Gokce Isik
* ID: 21803541
* Section : 2
* Homework : 2
* Description : Binary Search Tree
*/

#include "BSTNode.h"
#include <iostream>
using namespace std;

BSTNode::BSTNode():data(0), leftChild(NULL), rightChild(NULL){

}

BSTNode::BSTNode(const int& nodeItem, BSTNode *left, BSTNode *right):data(nodeItem), leftChild(left), rightChild(right){

}

BSTNode::BSTNode(const BSTNode &node):data(node.data), leftChild(node.leftChild), rightChild(node.rightChild){
}
