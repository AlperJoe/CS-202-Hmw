/**
* Title: Binary Search Trees
* Author : Gizem Gokce Isik
* ID: 21803541
* Section : 2
* Homework : 2
* Description : Binary Search Tree
*/

#include "BST.h"
#include <iostream>
using namespace std;

// default constructor
BST::BST() :root(NULL) {

}

// protected constructor
BST::BST(BSTNode *nodePtr) :root(nodePtr) {

}

// constructor
BST::BST(const int& rootItem){
    root = new BSTNode(rootItem,NULL,NULL);
}

// constructor
BST::BST(const int& rootItem, BST& leftTree, BST& rightTree) {
    root = new BSTNode(rootItem, NULL, NULL);
    attachLeftSubtree(leftTree);
    attachRightSubtree(rightTree);
}

void BST::attachLeftSubtree(BST& leftTree) {
    if (!isEmpty() && (root->leftChild == NULL)) {
        root->leftChild = leftTree.root;
        leftTree.root = NULL;

    }
}

void BST::attachRightSubtree(BST& rightTree) {
    if(!isEmpty() && (root -> rightChild == NULL)){
        root -> rightChild = rightTree.root;
        rightTree.root = NULL;
    }
}

// copy constructor
BST :: BST(const BST& tree){
    copyTree(tree.root, root);
}

void BST::copyTree(BSTNode* treePtr, BSTNode*& newTreePtr)const{

    if(treePtr != NULL){  //copy node
        newTreePtr = new BSTNode(treePtr -> data);
        copyTree(treePtr -> leftChild, newTreePtr -> leftChild);
        copyTree(treePtr -> rightChild, newTreePtr -> rightChild);
    }else{
        newTreePtr = NULL;  //copy empty tree
    }
}

// destructor
BST::~BST() {
    destruct(root);
}

void BST::destruct(BSTNode* treePtr){
    if(treePtr != NULL){
        destruct(treePtr -> leftChild);
        destruct(treePtr -> rightChild);
        delete treePtr;
        treePtr = NULL;
    }
}

bool BST::isEmpty(){
    return root == NULL;
}


//insertItem function for inserting a node for binary search tree
void BST::insertItem(int key)  {
    insertHelper(root, key);
}

//insertHelper function
void BST::insertHelper(BSTNode*& root,const int& key) {
    if (root == nullptr)
        root = new BSTNode(key, nullptr, nullptr);
    else if (key < root->data)
        insertHelper(root->leftChild, key);
    else
        insertHelper(root->rightChild, key);
}

//delete function
/*
 * The deleted node can be:
    – Case 1 – A leaf node.
    – Case 2 – A node with only one child
    (with left child or with right child).
    – Case 3 – A node with two children.
 */
void BST::deleteItem(int key) {
    deleteHelper(root, key);
}

//deleteHelper function
void BST::deleteHelper(BSTNode*& bstNode, const int& key) {
    if (bstNode == nullptr) // Empty tree
        return;
    else if (key == bstNode->data) //key is found
        deleteNodeItem(bstNode);
    else if (key < bstNode->data) //if the key is less than node data go leftChild
        deleteHelper(bstNode->leftChild, key);
    else //else the key is greater than node data go rightChild
        deleteHelper(bstNode->rightChild, key);
}

void BST::deleteNodeItem(BSTNode*& nodePtr) {
    BSTNode* delPtr;
    int replacementItem;

    //if the deleted node is a leaf
    if ( (nodePtr->leftChild == nullptr) &&
         (nodePtr->rightChild == nullptr) ) {
        delete nodePtr;
        nodePtr = nullptr;
    }

    // deleted node does not have left child
    else if (nodePtr->leftChild == nullptr){
        delPtr = nodePtr;
        nodePtr = nodePtr->rightChild;
        delPtr->rightChild = nullptr;
        delete delPtr;
    }
    // deleted node does not have right child
    else if (nodePtr->rightChild == nullptr) {
        delPtr = nodePtr;
        nodePtr = nodePtr->leftChild;
        delPtr->leftChild = nullptr;
        delete delPtr;
    }

    //deleted node has two children
    else {
        processLeftmost(nodePtr->rightChild, replacementItem);
        nodePtr->data = replacementItem;
    }
}

//process leftmost
void BST::processLeftmost(BSTNode*& nodePtr, int& item){
    if (nodePtr->leftChild == nullptr) {
        item = nodePtr->data;
        BSTNode* delPtr = nodePtr;
        nodePtr = nodePtr->rightChild;
        delPtr->rightChild = nullptr;
        delete delPtr;
    }
    else
        processLeftmost(nodePtr->leftChild, item);
}


//inorderTraversal function
int* BST::inorderTraversal(int& length){
    int* bstArray = new int[length];
    int index = 0;
    inorderTraversalHelper(root, bstArray, index);
    length = index;
    return bstArray;
}

//inorderTraversalHelper function
void BST::inorderTraversalHelper(BSTNode* bstNode, int* array, int& index){
    if (bstNode == nullptr) return;
    inorderTraversalHelper(bstNode->leftChild, array, index);
    array[index++] = bstNode->data;
    cout << bstNode->data << "  ";
    inorderTraversalHelper(bstNode->rightChild, array, index);
}

//hasSequence function
bool BST::hasSequence(int* seq, int length) {
    BSTNode* current = root;

    for (int i = 0; i < length; i++) {
        if (current == nullptr || current->data != seq[i]) {
            cout <<"false" << endl;
            return false;
        }
        cout << current->data << " ";
        if (i < length - 1 && seq[i + 1] < current->data) {
            current = current->leftChild;
        }
        else {
            current = current->rightChild;
        }
    }
    cout <<" ---> true" << endl;
    return true;
}





