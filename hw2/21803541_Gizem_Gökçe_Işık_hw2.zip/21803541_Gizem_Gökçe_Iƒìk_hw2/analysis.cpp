/**
* Title: Binary Search Trees
* Author : Gizem Gokce Isik
* ID: 21803541
* Section : 2
* Homework : 2
* Description : Binary Search Tree
*/
#include "analysis.h"
#include "BST.h"
#include <iostream>
using namespace std;
#include <cstdlib>
#include <chrono>
#include <ctime>

void timeAnalysis() {
    BST binarySearchTree;
    int *randomArray = new int[15000];
    clock_t start;
    clock_t end;
    const int size = 1500;

    cout << "Part e - Analysis of Binary Search Tree - part 1" << endl;
    cout << "------------------------------------------------" << endl;
    cout << "Tree Size \t\t" << "Time Elapsed \t\t" << endl;
    cout << "------------------------------------------------" << endl;

    for (int i = 0; i < 15000; ++i) {

        if ((i + 1) % size == 1) {
            start = clock();
        }
        randomArray[i] = rand() % 15000;
        binarySearchTree.insertItem(randomArray[i]);
        if ((i + 1) % size == 0) {
            end = clock();
            double duration =  (double(end - start) / CLOCKS_PER_SEC);
            cout << (i + 1) << " \t\t\t" <<  10000*duration << endl;
        }
    }

    std::chrono::time_point<std::chrono::system_clock> startTime2;
    std::chrono::duration<double, micro> duration2;

    cout << "Part e - Analysis of Binary Search Tree - part 2" << endl;
    cout << "------------------------------------------------" << endl;
    cout << "Tree Size \t\t" << "Time Elapsed \t\t" << endl;
    cout << "------------------------------------------------" << endl;

    //swap operation for shuffle
    int tempArray, j;
    for (int i = 15000; i > 0; i--) {
        j = rand() % (i + 1);
        tempArray = randomArray[i];
        randomArray[i] = randomArray[j];
        randomArray[j] = tempArray;
    }

    for (int i = 13500; i > 0; i--) {

        if((i+1) % size == 1 ) {
            startTime2 = std::chrono::system_clock::now();
        }

        binarySearchTree.deleteItem(randomArray[i]);

        if ((i + 1) % 1500 == 0) {
            duration2 = std::chrono::system_clock::now() - startTime2;
            cout << i + 1 << "\t\t\t" << 10 *(duration2.count()) << endl;
        }
    }

    delete[] randomArray;
}