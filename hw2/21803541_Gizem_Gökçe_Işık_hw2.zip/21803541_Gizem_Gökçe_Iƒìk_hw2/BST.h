/**
* Title: Binary Search Trees
* Author : Gizem Gokce Isik
* ID: 21803541
* Section : 2
* Homework : 2
* Description : Binary Search Tree
*/
#include "BSTNode.h"
#include <iostream>
using namespace std;

class BST {
public:
    BST(); //default constructor
    BST(BSTNode* node);  //protected constructor
    BST(const int& rootItem);  //constructor
    BST(const int& rootItem, BST& leftTree, BST& rightTree);  //constructor
    void attachLeftSubtree(BST& leftTree);
    void attachRightSubtree(BST& rightTree);
    BST(const BST& tree); //copy constructor
    void copyTree(BSTNode* treePtr, BSTNode*& newTreePtr)const;
    ~BST();
    bool isEmpty();
    void destruct(BSTNode *node);

    void insertItem(int key);
    void insertHelper(BSTNode*& root,const int& key);

    void deleteItem(int key);
    void deleteHelper(BSTNode*& root, const int& key);
    void deleteNodeItem(BSTNode*& nodePtr);
    void processLeftmost(BSTNode*& nodePtr, int& item);

    int* inorderTraversal(int& length);
    void inorderTraversalHelper(BSTNode* bstNode, int* array, int& index);

    bool hasSequence(int* seq, int length);
    bool hasSequenceHelper(BSTNode* node, int* seq, int index, int length);

    BSTNode* root;
};
