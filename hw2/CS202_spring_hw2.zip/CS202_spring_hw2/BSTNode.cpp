/**
* Title: Binary Search Trees
* Author : Gizem Gokce Isik
* ID: 21803541
* Section : 2
* Homework : 2
* Description : Binary Search Tree
*/

#include "BSTNode.h"
#include <iostream>
using namespace std;

BSTNode::BSTNode(const int& data, BSTNode* left, BSTNode* right) {
    this->data = data;
    this->leftChild = left;
    this->rightChild = right;
}