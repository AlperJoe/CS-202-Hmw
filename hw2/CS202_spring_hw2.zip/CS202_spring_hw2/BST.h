/**
* Title: Binary Search Trees
* Author : Gizem Gokce Isik
* ID: 21803541
* Section : 2
* Homework : 2
* Description : Binary Search Tree
*/
#include "BSTNode.h"
#include <iostream>
using namespace std;

class BST {
public:
    void insertItem(int key);
    void insertHelper(BSTNode*& root,const int& key);

    void deleteItem(int key);
    void deleteHelper(BSTNode*& root, const int& key);
    void deleteNodeItem(BSTNode*& nodePtr);
    void processLeftmost(BSTNode*& nodePtr, int& item);

    int* inorderTraversal(int& length);
    void inorderTraversalHelper(BSTNode* bstNode, int* array, int& index);

    bool hasSequence(int* seq, int length);
    bool hasSequenceHelper(BSTNode* node, int* seq, int index, int length);

    BSTNode* root;
};

/*BSTNode* mergeHelper(BSTNode* node1, BSTNode* node2) {
    if (node1 == nullptr) {
        return node2;
    }
    if (node2 == nullptr) {
        return node1;
    }
    BST result;
    result.insertItem(node1->data);
    result.insertItem(node2->data);
    result.root->leftChild = mergeHelper(node1->leftChild, node2->leftChild);
    result.root->rightChild = mergeHelper(node1->rightChild, node2->rightChild);
    return result.root;
}

BST* merge(const BST& tree1, const BST& tree2) {
    BSTNode* root = mergeHelper(tree1.root, tree2.root);
    BST* result = new BST();
    result->root = root;
    return result;
}*/