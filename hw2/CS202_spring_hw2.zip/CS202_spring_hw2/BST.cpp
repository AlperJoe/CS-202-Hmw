/**
* Title: Binary Search Trees
* Author : Gizem Gokce Isik
* ID: 21803541
* Section : 2
* Homework : 2
* Description : Binary Search Tree
*/

#include "BST.h"
#include <iostream>
using namespace std;

//insertItem function for inserting a node for binary search tree
void BST::insertItem(int key)  {
    insertHelper(root, key);
}

//insertHelper function
void BST::insertHelper(BSTNode*& root,const int& key) {
    if (root == nullptr)
        root = new BSTNode(key, nullptr, nullptr);
    else if (key < root->data)
        insertHelper(root->leftChild, key);
    else
        insertHelper(root->rightChild, key);
}

//delete function
/*
 * The deleted node can be:
    – Case 1 – A leaf node.
    – Case 2 – A node with only one child
    (with left child or with right child).
    – Case 3 – A node with two children.
 */
void BST::deleteItem(int key) {
    deleteHelper(root, key);
}

//deleteHelper function
void BST::deleteHelper(BSTNode*& bstNode, const int& key) {
    if (bstNode == nullptr) // Empty tree
        return;
    else if (key == bstNode->data) //key is found
        deleteNodeItem(bstNode);
    else if (key < bstNode->data) //if the key is less than node data go leftChild
        deleteHelper(bstNode->leftChild, key);
    else //else the key is greater than node data go rightChild
        deleteHelper(bstNode->rightChild, key);
}

void BST::deleteNodeItem(BSTNode*& nodePtr) {
    BSTNode* delPtr;
    int replacementItem;

    //if the deleted node is a leaf
    if ( (nodePtr->leftChild == nullptr) &&
         (nodePtr->rightChild == nullptr) ) {
        delete nodePtr;
        nodePtr = nullptr;
    }

    // deleted node does not have left child
    else if (nodePtr->leftChild == nullptr){
        delPtr = nodePtr;
        nodePtr = nodePtr->rightChild;
        delPtr->rightChild = nullptr;
        delete delPtr;
    }
    // deleted node does not have right child
    else if (nodePtr->rightChild == nullptr) {
        delPtr = nodePtr;
        nodePtr = nodePtr->leftChild;
        delPtr->leftChild = nullptr;
        delete delPtr;
    }

    //deleted node has two children
    else {
        processLeftmost(nodePtr->rightChild, replacementItem);
        nodePtr->data = replacementItem;
    }
}

//process leftmost
void BST::processLeftmost(BSTNode*& nodePtr, int& item){
    if (nodePtr->leftChild == nullptr) {
        item = nodePtr->data;
        BSTNode* delPtr = nodePtr;
        nodePtr = nodePtr->rightChild;
        delPtr->rightChild = nullptr;
        delete delPtr;
    }
    else
        processLeftmost(nodePtr->leftChild, item);
}


//inorderTraversal function
int* BST::inorderTraversal(int& length){
    int* bstArray = new int[length];
    int index = 0;
    inorderTraversalHelper(root, bstArray, index);
    length = index;
    return bstArray;
}

//inorderTraversalHelper function
void BST::inorderTraversalHelper(BSTNode* bstNode, int* array, int& index){
    if (bstNode == nullptr) return;
    inorderTraversalHelper(bstNode->leftChild, array, index);
    array[index++] = bstNode->data;
    cout << bstNode->data << "  ";
    inorderTraversalHelper(bstNode->rightChild, array, index);
}

//hasSequence function
bool BST::hasSequence(int* seq, int length) {
    BSTNode* current = root;

    for (int i = 0; i < length; i++) {
        if (current == nullptr || current->data != seq[i]) {
            cout <<"false" << endl;
            return false;
        }
        cout << current->data << " ";
        if (i < length - 1 && seq[i + 1] < current->data) {
            current = current->leftChild;
        }
        else {
            current = current->rightChild;
        }
    }
    cout <<" ---> true" << endl;
    return true;
}





