/**
* Title: Binary Search Trees
* Author : Gizem Gokce Isik
* ID: 21803541
* Section : 2
* Homework : 2
* Description : Binary Search Tree
*/
#include "BST.h"
#include "analysis.h"
#include <iostream>
using namespace std;

int main() {

    BST bst;
    int size = 12;

    bst.insertItem(1);
    bst.insertItem(2);
    bst.insertItem(3);
    bst.insertItem(4);
    bst.insertItem(5);
    bst.insertItem(6);

    bst.insertItem(8);
    bst.insertItem(10);
    bst.insertItem(12);
    bst.insertItem(13);
    bst.insertItem(14);
    bst.insertItem(15);

    bst.inorderTraversal(size);
    cout << endl;

    cout << "First subArray: "<< endl;
    int subArray1[6] = {1,2,3,4,5,6};
    bst.hasSequence(subArray1, 6);

    cout << "Second subArray: "<< endl;
    int subArray2[4] = {10,12,13,15};
    bst.hasSequence(subArray2, 4);

    cout << "Third subArray: "<< endl;
    int subArray3[3] = {10,11,12};
    bst.hasSequence(subArray3, 3);

    bst.deleteItem(8);
    size--;
    bst.inorderTraversal(size);

    cout<< endl;
    timeAnalysis();

    return 0;
}
