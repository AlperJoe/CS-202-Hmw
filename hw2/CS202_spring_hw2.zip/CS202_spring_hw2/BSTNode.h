/**
* Title: Binary Search Trees
* Author : Gizem Gokce Isik
* ID: 21803541
* Section : 2
* Homework : 2
* Description : Binary Search Tree
*/
#include <iostream>
using namespace std;

class BSTNode {
public:
    BSTNode(const int& data, BSTNode* left, BSTNode* right);
    int data;
    BSTNode* leftChild;
    BSTNode* rightChild;
};
