//
//  analysis.cpp
//  Trees-hmw
//
//  Created by Alper Bozkurt on 24.03.2023.
//

#include <stdio.h>
#include "analysis.h"
#include  "BST.h"
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

void timeAnalysis(){
    BST tree;
    const int arraySize = 15000;
    const int elapsedSize = 1500;
    int* arr = new int[arraySize];
    
    clock_t start = clock();
    
    //creates random array measuring time while inserting
    for(int index = 0; index < arraySize; index++){
        arr[index] = rand() % arraySize; //random number in range 0 to array size
        tree.insertItem(arr[index]);
        
        if((index + 1) % elapsedSize == 0){
            clock_t end = clock();
            double duration = double(end - start) / CLOCKS_PER_SEC;
            cout<<"Time elapsed for "<<index+1<<" insertion: "<<duration<<endl;
        }
    }
    cout<<endl;
    
    //shuffle the array
    for(int j = 0; j < arraySize; j++){
        int k = rand() % arraySize;  //random number in range 0 to array size
        
        int temp = arr[j];
        arr[j] = arr[k];
        arr[k] = temp;
    }
    
    start = clock();
    for(int i = 0; i < arraySize; i++){
        tree.deleteItem(arr[i]);
        
        if((i + 1) % elapsedSize == 0){
            clock_t end = clock();
            double duration = double(end - start) / CLOCKS_PER_SEC;
            cout<<"Time elapsed for " << i + 1 << " deletions: "<<duration<<endl;
        }
    }
}
