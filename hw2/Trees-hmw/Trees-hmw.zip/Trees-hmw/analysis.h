//
//  analysis.h
//  Trees-hmw
//
//  Created by Alper Bozkurt on 24.03.2023.
//

#ifndef analysis_h
#define analysis_h

void timeAnalysis();

#endif /* analysis_h */
