/**
* Title: Binary Search Trees
* Author : Alper Bozkurt
* ID: 21802766
* Section : 2
* Homework : 2
* Description : Analysis class for measure time in the process of
 inserting and deleting element time and display it.
 */


#ifndef analysis_h
#define analysis_h

void timeAnalysis();
#endif /* analysis_h */
