//
//  Snack.cpp
//  hw4
//
//  Created by Alper Bozkurt on 17.05.2023.
//

#include <stdio.h>
#include <iostream>
#include <string>
#include <list>
#include "Snack.h"
using namespace std;

Snack::Snack(string name) {
    this->name = name;
}
